package Exception;

public class EmptyStringException extends Exception {

    public EmptyStringException(String errorMessage) {
        super(errorMessage);
    }
}
