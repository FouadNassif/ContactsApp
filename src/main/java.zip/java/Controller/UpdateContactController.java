package Controller;

import view.UpdateContactView;

public class UpdateContactController {

    UpdateContactView updateContactView;

    public UpdateContactController(UpdateContactView view) {
        updateContactView = view;
    }
}
