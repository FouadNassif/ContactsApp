package java3.nfa035_fouadnassif_2339t;

import java.io.File;

public class GlobalVariables {

    public static final String CONTACT_FILE_NAME = "./Contacts.obj";
    public static final String GROUP_FILE_NAME = "./Groups.obj";

    public static final File CONTACT_FILE = new File(CONTACT_FILE_NAME);
    public static final File GROUP_FILE = new File(GROUP_FILE_NAME);
}
